# WSI_Coding_Challenge

The purpose of this project is to demonstrate my level of Java coding competency. The problem that is being solved is: Given a collection of 5 digit zip codes, produce the minimum number of ranges that represent the same restrictions as the input.

## Usage
main.java is a runnable class which takes in user input of zip codes and outputs the minimized list.
The project can be ran a number of ways but the easiest would be to download the zip file and use your IDE to Open Project, then run main.java.

## Tests
All of the tests can be found under the test/com/zipchallenge directory.
